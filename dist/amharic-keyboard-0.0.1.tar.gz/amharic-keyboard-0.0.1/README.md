# Amharic-keyboard
This is a simple package that lets you type Amharic letters using Latin alphabet. 

It will analyze the given Latin text for consonants and vowels and converts those words in to the equaivalent of Amharic words.

It follws the same pattern used for typing Amharic words when texting.

#Installation:

`pip install amharic-keyboard`


#usage

```
import AmharicKeyboard as AK

keyboard = Ak
keyboard.transform("selam nachihu")

```

